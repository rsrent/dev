import React, {Component} from 'react';
import {Link, Redirect} from "react-router-dom";

let Config = require('./config.json');


class CleaningPlan extends Component {
    constructor(props) {
        super(props);
        if (props.location.state !== undefined) {
            this.state = {
                floors: props.location.state.floors,
                locationID: props.match.params.locationID,
                planType: props.match.params.type,
                floorID: props.match.params.floor,
                redirect: false
            }
        } else {
            this.state = {
                floors: [],
                locationID: props.match.params.locationID,
                planType: props.match.params.type,
                floorID: props.match.params.floor,
                redirect: false
            };
            this.getFloors();
        }
    }

    getFloors() {
        let myHeaders = new Headers();
        myHeaders.append("Authorization", "Bearer " + localStorage.getItem('token'));
        fetch(Config.API_URL + "/CleaningTask/Floors/" + this.state.locationID + "/" + this.state.planType, {
            method: "GET",
            headers: myHeaders
        })
            .then(result => {
                if (!result.ok) {
                    throw result;
                }
                return result.json();
            })
            .then(floors => this.setState({floors: floors}))
            .catch(error => {
                console.error("ERROOOOR", error);
                if (error.status === 400) {
                    this.setState({redirect: true})
                } else if (error.status === 404) {
                    throw error;
                } else if (error.status === 401) {
                    localStorage.clear();
                    window.location.replace("/");
                } else {
                    alert("Der skete en ukendt serverfejl");
                }
            })
            .catch(async errorResult => {
                let result = await errorResult.json();
                alert(result);
            });
    }

    render() {
        return (

            <div className="buttons-group">
                {this.state.redirect &&
                <Redirect to={"/Locations/User/" + this.props.match.params.userID + "/" + this.props.match.params.locationID + "/CleaningPlan"}/>}
                {/*console.log(this.props.location.state.floors)*/}
                {
                    this.state.floors.length ?
                        this.state.floors.map(floor =>
                            <div className="button-content" key={floor.floor.id}>
                                <Link className="btn btn-simp btn-primary select-button" href="#" role="button"
                                      to={{
                                          pathname: `/Locations/${this.props.match.params.locationID}/CleaningPlans/${this.props.match.params.type}/Floors/${floor.floor.id}/`,
                                          state: {tasks: floor.areas}
                                      }}>{floor.floor.description}</Link>
                            </div>
                        ) :
                        <p>Loading...</p>
                }
            </div>
        );
    }
}

export default CleaningPlan;
//http://jsfiddle.net/weqm8q5w/6/